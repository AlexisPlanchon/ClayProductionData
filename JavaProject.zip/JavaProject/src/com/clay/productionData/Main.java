package com.clay.productionData;

/**
 * @author Alexis
 *
 */
public class Main {

	/**
	 * Run the application
	 * 
	 * @param args (String[])
	 */
	public static void main(String[] args) {
		new MainFrame();
	}
}
