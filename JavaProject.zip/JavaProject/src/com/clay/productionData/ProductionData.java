package com.clay.productionData;

import java.sql.Date;

/**
 * @author Alexis
 *
 */
public class ProductionData {
	private int id;
	private String date;
	private int timecode;
	private int lot;
	private int offset;
	private int pressure;
	private int layout;
	private String component;
	private String colorbound;
	private String quality;
	private String performance;
	private int result;

	/**
	 * Display all the data of a ProductionData
	 */
	@Override
	public String toString() {
		return "donneeProduction [id=" + id + ", date=" + date + ", timecode=" + timecode + ", lot=" + lot + ", offset="
				+ offset + ", pressure=" + pressure + ", layout=" + layout + ", component=" + component
				+ ", colorbound=" + colorbound + ", quality=" + quality + ", performance=" + performance + ", result="
				+ result + "]";
	}

	/**
	 * Build an object ProductionData with this parameters : id, date, timecode,
	 * lot, offset, pressure, layout, component, colorbound, quality, performance
	 * and result
	 * 
	 * @param id (int)
	 * @param date (date)
	 * @param timecode (int)
	 * @param lot (int)
	 * @param offset (int)
	 * @param pressure (int)
	 * @param layout (int)
	 * @param component (String)
	 * @param colorbound (String)
	 * @param quality (String)
	 * @param performance (String)
	 * @param result (int)
	 */
	public ProductionData(int id, Date date, int timecode, int lot, int offset, int pressure, int layout,
			String component, String colorbound, String quality, String performance, int result) {
		super();
		this.id = id;
		this.date = date.toString();
		this.timecode = timecode;
		this.lot = lot;
		this.offset = offset;
		this.pressure = pressure;
		this.layout = layout;
		this.component = component;
		this.colorbound = colorbound;
		this.quality = quality;
		this.performance = performance;
		this.result = result;
	}

	/**
	 * Get the id of a ProductionData
	 * 
	 * @return int
	 */
	public int getId() {
		return id;
	}

	/**
	 * Set the id of a ProductionData
	 * 
	 * @param id (int)
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * Get the date of a ProductionData
	 * 
	 * @return String
	 */
	public String getDate() {
		return date;
	}

	/**
	 * Set the date of a ProductionData
	 * 
	 * @param date (date)
	 */
	public void setDate(String date) {
		this.date = date;
	}

	/**
	 * Get the timecode of a ProductionData
	 * 
	 * @return int
	 */
	public int getTimecode() {
		return timecode;
	}

	/**
	 * Set the timecode of a ProductionData
	 * 
	 * @param timecode (int)
	 */
	public void setTimecode(int timecode) {
		this.timecode = timecode;
	}

	/**
	 * Get the lot of a ProductionData
	 * 
	 * @return int
	 */
	public int getLot() {
		return lot;
	}

	/**
	 * Set the lot of a ProductionData
	 * 
	 * @param lot (int)
	 */
	public void setLot(int lot) {
		this.lot = lot;
	}

	/**
	 * Get the offset of a ProductionData
	 * 
	 * @return int
	 */
	public int getOffset() {
		return offset;
	}

	/**
	 * Set the offset of a ProductionData
	 * 
	 * @param offset (int)
	 */
	public void setOffset(int offset) {
		this.offset = offset;
	}

	/**
	 * Get the pressure of a ProductionData
	 * 
	 * @return int
	 */
	public int getPressure() {
		return pressure;
	}

	/**
	 * Set the pressure of a ProductionData
	 * 
	 * @param pressure (int)
	 */
	public void setPressure(int pressure) {
		this.pressure = pressure;
	}

	/**
	 * Get the layout of a ProductionData
	 * 
	 * @return int
	 */
	public int getLayout() {
		return layout;
	}

	/**
	 * Set the layout of a ProductionData
	 * 
	 * @param layout (int)
	 */
	public void setLayout(int layout) {
		this.layout = layout;
	}

	/**
	 * Get the component of a ProductionData
	 * 
	 * @return String
	 */
	public String getComponent() {
		return component;
	}

	/**
	 * Set the component of a ProductionData
	 * 
	 * @param component (String)
	 */
	public void setComponent(String component) {
		this.component = component;
	}

	/**
	 * Get the colorbound of a ProductionData
	 * 
	 * @return String
	 */
	public String getColorbound() {
		return colorbound;
	}

	/**
	 * Set the colorbound of a ProductionData
	 * 
	 * @param colorbound (String)
	 */
	public void setColorbound(String colorbound) {
		this.colorbound = colorbound;
	}

	/**
	 * Get the quality of a ProductionData
	 * 
	 * @return String
	 */
	public String getQuality() {
		return quality;
	}

	/**
	 * Set the quality of a ProductionData
	 * 
	 * @param quality (String)
	 */
	public void setQuality(String quality) {
		this.quality = quality;
	}

	/**
	 * Get the performance of a ProductionData
	 * 
	 * @return String
	 */
	public String getPerformance() {
		return performance;
	}

	/**
	 * Set the performance of a ProductionData
	 * 
	 * @param performance (String)
	 */
	public void setPerformance(String performance) {
		this.performance = performance;
	}

	/**
	 * Get the result of a ProductionData
	 * 
	 * @return int
	 */
	public int getResult() {
		return result;
	}

	/**
	 * Set the result of a ProductionData
	 * 
	 * @param result (int)
	 */
	public void setResult(int result) {
		this.result = result;
	}

}
