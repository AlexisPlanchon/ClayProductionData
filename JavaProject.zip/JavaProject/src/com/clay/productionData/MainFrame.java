package com.clay.productionData;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.Calendar;
import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/**
 * @author Alexis
 *
 */
public class MainFrame {
	private JFrame jFrame;
	private JTable jTable;
	private String columnsNames[] = { "id", "date", "timecode", "lot", "offset", "pressure", "layout", "component",
			"colorbound", "quality", "performance", "result" };
	private String orderList[] = { "ASC", "DESC" };
	private String qualityOrPerformanceList[] = { "quality", "performance" };
	private String monthList[] = { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12" };
	private String lotOrComponentOrLayoutList[] = { "lot", "component", "layout" };
	String yearList[] = { Integer.toString(Calendar.getInstance().get(Calendar.YEAR)),
			Integer.toString(Calendar.getInstance().get(Calendar.YEAR) - 1),
			Integer.toString(Calendar.getInstance().get(Calendar.YEAR) - 2) };

	/**
	 * Display the main Frame
	 */
	MainFrame() {

		// Principal jFrame
		jFrame = new JFrame("Clay - Production Datas");
		Dimension screenDimensions = new Dimension(Toolkit.getDefaultToolkit().getScreenSize());

		// Create jPanel
		JPanel jPanel = new JPanel(new BorderLayout());
		jPanel.setBounds(200, 200, screenDimensions.width - 400, 470);

		// Create jLabel
		final JLabel jLabel = new JLabel();
		jLabel.setHorizontalAlignment(JLabel.CENTER);
		jLabel.setSize(400, 100);
		jFrame.add(jLabel);

		// Table creation
		DefaultTableModel defaultTableModel = new DefaultTableModel(columnsNames, 0);
		MainFrameUtils.fillTable(defaultTableModel, GetData.getAllData());
		jTable = new JTable(defaultTableModel);
		jTable.getColumnModel().getColumn(8).setCellRenderer(new CustomRenderer());
		JScrollPane jTableScrollPane = new JScrollPane(jTable);
		jPanel.add(jTable.getTableHeader(), BorderLayout.PAGE_START);
		jPanel.add(jTableScrollPane, BorderLayout.CENTER);
		jFrame.add(jPanel);

		int leftBorder = screenDimensions.width - 1000;

		// Generate Graph part
		JLabel labelGenerateGraph = new JLabel("Generate Graph : ");
		labelGenerateGraph.setBounds(leftBorder, 10, 100, 20);
		jFrame.add(labelGenerateGraph);

		final JComboBox<?> jComboBoxQualityOrPerformance = new JComboBox<Object>(qualityOrPerformanceList);
		jComboBoxQualityOrPerformance.setBounds(leftBorder + 110, 10, 90, 20);
		jFrame.add(jComboBoxQualityOrPerformance);

		JLabel labelGenerateGraphPart2 = new JLabel(" / ");
		labelGenerateGraphPart2.setBounds(leftBorder + 210, 10, 10, 20);
		jFrame.add(labelGenerateGraphPart2);

		final JComboBox<?> jComboBoxLotOrComponentOrLayout = new JComboBox<Object>(lotOrComponentOrLayoutList);
		jComboBoxLotOrComponentOrLayout.setBounds(leftBorder + 230, 10, 90, 20);
		jFrame.add(jComboBoxLotOrComponentOrLayout);

		JTextField jTextFieldValueForGraph = new JTextField("Value");
		jTextFieldValueForGraph.setBounds(leftBorder + 330, 10, 90, 20);
		jFrame.add(jTextFieldValueForGraph);

		JButton validateGraphButton = new JButton("Generate Graph");
		validateGraphButton.setBounds(leftBorder + 440, 10, 130, 20);
		jFrame.add(validateGraphButton);

		// Generate Graph part
		JLabel labelGenerateReport = new JLabel("Generate Report : ");
		labelGenerateReport.setBounds(leftBorder, 50, 120, 20);
		jFrame.add(labelGenerateReport);

		final JComboBox<?> jComboBoxMonthList = new JComboBox<Object>(monthList);
		jComboBoxMonthList.setBounds(leftBorder + 110, 50, 90, 20);
		jFrame.add(jComboBoxMonthList);

		JLabel labelGenerateReportPart2 = new JLabel(" / ");
		labelGenerateReportPart2.setBounds(leftBorder + 210, 50, 10, 20);
		jFrame.add(labelGenerateReportPart2);

		final JComboBox<?> jComboBoxYearList = new JComboBox<Object>(yearList);
		jComboBoxYearList.setBounds(leftBorder + 230, 50, 90, 20);
		jFrame.add(jComboBoxYearList);

		JButton validateButtonExport = new JButton("Generate Report");
		validateButtonExport.setBounds(leftBorder + 440, 50, 130, 20);
		jFrame.add(validateButtonExport);

		// Filter part
		JLabel labelFilter = new JLabel("Filter Board : ");
		labelFilter.setBounds(leftBorder, 90, 120, 20);
		jFrame.add(labelFilter);

		final JComboBox<?> jComboBoxColumnListFilter = new JComboBox<Object>(columnsNames);
		jComboBoxColumnListFilter.setBounds(leftBorder + 110, 90, 90, 20);
		jFrame.add(jComboBoxColumnListFilter);

		JLabel labelFilterPart2 = new JLabel(" / ");
		labelFilterPart2.setBounds(leftBorder + 210, 90, 10, 20);
		jFrame.add(labelFilterPart2);

		final JComboBox<?> jComboBoxOrderList = new JComboBox<Object>(orderList);
		jComboBoxOrderList.setBounds(leftBorder + 230, 90, 90, 20);
		jFrame.add(jComboBoxOrderList);

		JButton validateButtonFilters = new JButton("Validate Filter");
		validateButtonFilters.setBounds(leftBorder + 440, 90, 130, 20);
		jFrame.add(validateButtonFilters);

		// Search part
		JLabel labelSearch = new JLabel("Search Board : ");
		labelSearch.setBounds(leftBorder, 130, 120, 20);
		jFrame.add(labelSearch);

		final JComboBox<?> jComboBoxColumnListSearch = new JComboBox<Object>(columnsNames);
		jComboBoxColumnListSearch.setBounds(leftBorder + 110, 130, 90, 20);
		jFrame.add(jComboBoxColumnListSearch);

		JLabel labelSearchPart2 = new JLabel(" / ");
		labelSearchPart2.setBounds(leftBorder + 210, 130, 10, 20);
		jFrame.add(labelSearchPart2);

		JTextField jTextFieldValueForSearch = new JTextField("Value");
		jTextFieldValueForSearch.setBounds(leftBorder + 230, 130, 90, 20);
		jFrame.add(jTextFieldValueForSearch);

		JButton validateButtonSearch = new JButton("Validate Search");
		validateButtonSearch.setBounds(leftBorder + 440, 130, 130, 20);
		jFrame.add(validateButtonSearch);

		// Incorrect part
		JButton incorrectDataButton = new JButton("Get Incorrect Data");
		incorrectDataButton.setBounds(leftBorder + 200, 170, 150, 20);
		jFrame.add(incorrectDataButton);

		// Buttons functions
		validateButtonExport.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					JFileChooser chooser = new JFileChooser();
					chooser.setCurrentDirectory(new File("." + File.separator));
					int reponse = chooser.showDialog(chooser, "Save as");
					if (reponse == JFileChooser.APPROVE_OPTION) {
						String month = jComboBoxMonthList.getSelectedItem().toString();
						String year = jComboBoxYearList.getSelectedItem().toString();
						GenerateReport.generateReport(month, year, chooser.getSelectedFile().toString());
						JOptionPane.showMessageDialog(null, "XML File generated !");
					}
				} catch (Exception e1) {
					System.err.println("Got an exception! ");
					System.err.println(e1.getMessage());
				}
			}
		});

		validateButtonFilters.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MainFrameUtils.clearTable(defaultTableModel);
				MainFrameUtils.fillTable(defaultTableModel,
						GetData.getDataFilterBy(jComboBoxColumnListFilter.getSelectedItem().toString(),
								jComboBoxOrderList.getSelectedItem().toString()));
			}
		});

		validateGraphButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MainFrameUtils.generateGraph(jComboBoxQualityOrPerformance.getSelectedItem().toString(),
						jComboBoxLotOrComponentOrLayout.getSelectedItem().toString(),
						jTextFieldValueForGraph.getText().toString());
			}
		});

		incorrectDataButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MainFrameUtils.clearTable(defaultTableModel);
				MainFrameUtils.fillTable(defaultTableModel, GetData.getIncorrectData());
			}
		});

		validateButtonSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MainFrameUtils.clearTable(defaultTableModel);
				MainFrameUtils.fillTable(defaultTableModel,
						GetData.getDataFilteredByAField(jComboBoxColumnListSearch.getSelectedItem().toString(),
								jTextFieldValueForSearch.getText().toString()));
			}
		});

		// Headers Menu
		JMenuBar jMenuBar = new JMenuBar();
		JMenu jMenuFichier = new JMenu("File");
		JMenuItem jMenuItemLoadFile = new JMenuItem(new AbstractAction("Insert data") {
			private static final long serialVersionUID = 1L;

			public void actionPerformed(ActionEvent e) {
				JFileChooser choix = new JFileChooser();
				int retour = choix.showOpenDialog(jFrame);
				if (retour == JFileChooser.APPROVE_OPTION) {
					InsertData.insertionFichierXML(choix.getSelectedFile().getAbsolutePath());
					JOptionPane.showMessageDialog(null, "XML File inserted !");
					MainFrameUtils.clearTable(defaultTableModel);
					MainFrameUtils.fillTable(defaultTableModel, GetData.getAllData());
				}
			}
		});
		jMenuFichier.add(jMenuItemLoadFile);
		JMenuItem jMenuItemExitApplication = new JMenuItem(new AbstractAction("Exit") {
			private static final long serialVersionUID = 1L;

			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		jMenuFichier.add(jMenuItemExitApplication);
		jMenuBar.add(jMenuFichier);
		jFrame.setJMenuBar(jMenuBar);

		// jFrame options
		jFrame.setLayout(null);
		jFrame.setSize(screenDimensions.width, screenDimensions.height);
		jFrame.setVisible(true);
	}
}