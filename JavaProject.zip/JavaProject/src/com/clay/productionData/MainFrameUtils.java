package com.clay.productionData;

import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.awt.print.PrinterJob;
import java.util.List;
import javax.swing.AbstractAction;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.table.DefaultTableModel;

/**
 * @author Alexis
 *
 */
public class MainFrameUtils {

	/**
	 * Take a defaultTableModel to fill, complete the table with each productions
	 * data from the list dataFromDatabase
	 * 
	 * @param defaultTableModel (DefaultTableModel)
	 * @param dataFromDatabase (List<ProductionData>)
	 */

	public static void fillTable(DefaultTableModel defaultTableModel, List<ProductionData> dataFromDatabase) {
		for (ProductionData currentProductionData : dataFromDatabase) {
			defaultTableModel.addRow(new Object[] { currentProductionData.getId(), currentProductionData.getDate(),
					currentProductionData.getTimecode(), currentProductionData.getLot(),
					currentProductionData.getOffset(), currentProductionData.getPressure(),
					currentProductionData.getLayout(), currentProductionData.getComponent(),
					currentProductionData.getColorbound(), currentProductionData.getQuality(),
					currentProductionData.getPerformance(), currentProductionData.getResult() });
		}
	}

	/**
	 * Take a defaultTableModel to clear, for each rows of this table, delete the
	 * row
	 * 
	 * @param defaultTableModel (DefaultTableModel)
	 */

	public static void clearTable(DefaultTableModel defaultTableModel) {
		if (defaultTableModel.getRowCount() > 0) {
			for (int i = defaultTableModel.getRowCount() - 1; i > -1; i--) {
				defaultTableModel.removeRow(i);
			}
		}
	}

	/**
	 * Generate a jFrame with a graph of qualityOrPerformance/lotOrComponentOrLayout
	 * for a given lotOrComponentOrLayoutValue
	 * 
	 * @param qualityOrPerformance (String)
	 * @param lotOrComponentOrLayout (String)
	 * @param lotOrComponentOrLayoutValue (String)
	 */
	public static void generateGraph(String qualityOrPerformance, String lotOrComponentOrLayout,
			String lotOrComponentOrLayoutValue) {

		JFrame jFrame = new JFrame("Clay - Production Datas");
		jFrame.setSize(500, 400);

		int nbLow = GetData.getCountOfElementFilteredByTwoField(qualityOrPerformance, "Low", lotOrComponentOrLayout,
				lotOrComponentOrLayoutValue);
		int nbMedium = GetData.getCountOfElementFilteredByTwoField(qualityOrPerformance, "Medium",
				lotOrComponentOrLayout, lotOrComponentOrLayoutValue);
		int nbHigh = GetData.getCountOfElementFilteredByTwoField(qualityOrPerformance, "High", lotOrComponentOrLayout,
				lotOrComponentOrLayoutValue);

		String[] names = new String[] { "Low (" + nbLow + ")", "Medium (" + nbMedium + ")", "High (" + nbHigh + ")" };
		int[] values = new int[] { nbLow, nbMedium, nbHigh };
		jFrame.getContentPane().add(new GenerateGraph(values, names, "Graph - " + qualityOrPerformance + "/"
				+ lotOrComponentOrLayout + " - " + lotOrComponentOrLayoutValue));

		WindowListener wndCloser = new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		};

		// Headers menus
		JMenuBar jMenuBar = new JMenuBar();
		JMenu jMenuFichier = new JMenu("File");
		JMenuItem jMenuItemPrintGraph = new JMenuItem(new AbstractAction("Print graph") {
			private static final long serialVersionUID = 1L;

			public void actionPerformed(ActionEvent e) {
				MainFrameUtils.printFrame(jFrame);
			}
		});
		jMenuFichier.add(jMenuItemPrintGraph);
		JMenuItem jMenuItemExitApplication = new JMenuItem(new AbstractAction("Close graph") {
			private static final long serialVersionUID = 1L;

			public void actionPerformed(ActionEvent e) {
				jFrame.setVisible(false);
			}
		});
		jMenuFichier.add(jMenuItemExitApplication);
		jMenuBar.add(jMenuFichier);
		jFrame.setJMenuBar(jMenuBar);

		jFrame.addWindowListener(wndCloser);
		jFrame.setVisible(true);
	}

	/**
	 * Take a jFrame to print, and start a printerJob to print the jFrame
	 * 
	 * @param jFrame (JFrame)
	 */
	static void printFrame(JFrame jFrame) {
		try {
			final String frameTitle = jFrame.getTitle();
			PrinterJob printerJob = PrinterJob.getPrinterJob();
			printerJob.setJobName("Printer job for '" + frameTitle + "' window");
			final PageFormat pageFormat = printerJob.defaultPage();
			final PageFormat pageFormat2 = printerJob.pageDialog(pageFormat);
			if (pageFormat2 != pageFormat) {
				printerJob.setPrintable((Printable) jFrame, pageFormat2);
				if (printerJob.printDialog()) {
					printerJob.print();
				}
			}
		} catch (Exception e) {
			System.err.println("Got an exception! ");
			System.err.println(e.getMessage());
		}
	}
}