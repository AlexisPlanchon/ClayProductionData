package com.clay.productionData;

import java.awt.Color;
import java.awt.Component;
import java.lang.reflect.Field;

import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

/**
 * @author Alexis
 *
 */
class CustomRenderer extends DefaultTableCellRenderer {
	private static final long serialVersionUID = 1L;

	/**
	 * Overwrited method, color a cell of a given table in coordinate (row, column),
	 * colored the cell as the value of the cell
	 */
	public Component getTableCellRendererComponent(JTable jTable, Object value, boolean isSelected, boolean hasFocus,
			int row, int column) {
		Component cellComponent = super.getTableCellRendererComponent(jTable, value, isSelected, hasFocus, row, column);
		String colorOfRaw = jTable.getValueAt(row, column).toString().toLowerCase();
		Color color;
		try {
			Field field = Class.forName("java.awt.Color").getField(colorOfRaw);
			color = (Color) field.get(null);
		} catch (Exception e) {
			color = null;
		}
		cellComponent.setBackground(color);
		return cellComponent;
	}
}