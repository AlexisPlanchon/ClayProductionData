package com.clay.productionData;

import java.io.File;
import java.util.List;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 * @author Alexis
 *
 */
public class GenerateReport {

	/**
	 * Generate a report for a given month and year, the file is generated at given
	 * path xmlFilePath
	 * 
	 * @param month (int)
	 * @param year (int)
	 * @param xmlFilePath (String)
	 */
	public static void generateReport(String month, String year, String xmlFilePath) {
		try {
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
			Document document = documentBuilder.newDocument();

			List<ProductionData> data = GetData.getReportData(month, year);

			// Create reportField
			Element reportField = document.createElement("report");
			document.appendChild(reportField);

			for (ProductionData currentProductionData : data) {

				// Create dataField
				Element dataField = document.createElement("data");
				reportField.appendChild(dataField);

				// Add attribute lot to dataField
				Attr lotField = document.createAttribute("lot");
				lotField.setValue(Integer.toString(currentProductionData.getLot()));
				dataField.setAttributeNode(lotField);

				// Add attribute quality to dataField
				Element qualityField = document.createElement("quality");
				qualityField.appendChild(document.createTextNode(currentProductionData.getQuality()));
				dataField.appendChild(qualityField);

				// Add attribute performance to dataField
				Element performanceField = document.createElement("performance");
				performanceField.appendChild(document.createTextNode(currentProductionData.getPerformance()));
				dataField.appendChild(performanceField);

				// Add attribute colorbound to dataField
				Element colorField = document.createElement("colorbound");
				colorField.appendChild(document.createTextNode(currentProductionData.getColorbound()));
				dataField.appendChild(colorField);

				// Add attribute component to dataField
				Element componentField = document.createElement("component");
				componentField.appendChild(document.createTextNode(currentProductionData.getComponent()));
				dataField.appendChild(componentField);
			}

			// Create XML file
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource domSource = new DOMSource(document);
			StreamResult streamResult = new StreamResult(new File(xmlFilePath));
			transformer.transform(domSource, streamResult);

		} catch (Exception e) {
			System.err.println("Got an exception! ");
			System.err.println(e.getMessage());
		}
	}
}