package com.clay.productionData;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Alexis
 *
 */
public class GetData {

	/**
	 * Return list of all the productions data from the database
	 * 
	 * @return List<ProductionData>
	 */
	public static List<ProductionData> getAllData() {
		try {
			List<ProductionData> listResults = new ArrayList<ProductionData>();
			String myDriver = "com.mysql.cj.jdbc.Driver";
			String myUrl = "jdbc:mysql://localhost/javaproject?zeroDateTimeBehavior=CONVERT_TO_NULL&serverTimezone=UTC";
			Class.forName(myDriver);
			Connection conn = DriverManager.getConnection(myUrl, "root", "");
			String query = "SELECT * FROM donneesProduction";
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery(query);

			while (rs.next()) {
				int id = rs.getInt("id");
				Date date = rs.getDate("date");
				int timecode = rs.getInt("timecode");
				int lot = rs.getInt("lot");
				int offset = rs.getInt("offset");
				int pressure = rs.getInt("pressure");
				int layout = rs.getInt("layout");
				String component = rs.getString("component");
				String colorbound = rs.getString("colorbound");
				String quality = rs.getString("quality");
				String performance = rs.getString("performance");
				int result = rs.getInt("result");

				listResults.add(new ProductionData(id, date, timecode, lot, offset, pressure, layout, component,
						colorbound, quality, performance, result));
			}
			st.close();
			return listResults;

		} catch (Exception e) {
			System.err.println("Got an exception! ");
			System.err.println(e.getMessage());
		}
		return null;
	}

	/**
	 * Return list of all the productions data from the database filtered on a given
	 * column filter by order ascORdesc
	 * 
	 * @param filter (String)
	 * @param ascORdesc (String)
	 * @return List<ProductionData>
	 */
	public static List<ProductionData> getDataFilterBy(String filter, String ascORdesc) {
		try {
			List<ProductionData> listResults = new ArrayList<ProductionData>();
			String myDriver = "com.mysql.cj.jdbc.Driver";
			String myUrl = "jdbc:mysql://localhost/javaproject?zeroDateTimeBehavior=CONVERT_TO_NULL&serverTimezone=UTC";
			Class.forName(myDriver);
			Connection conn = DriverManager.getConnection(myUrl, "root", "");
			String query = "SELECT * FROM donneesProduction ORDER BY " + filter + " " + ascORdesc;
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery(query);

			while (rs.next()) {
				int id = rs.getInt("id");
				Date date = rs.getDate("date");
				int timecode = rs.getInt("timecode");
				int lot = rs.getInt("lot");
				int offset = rs.getInt("offset");
				int pressure = rs.getInt("pressure");
				int layout = rs.getInt("layout");
				String component = rs.getString("component");
				String colorbound = rs.getString("colorbound");
				String quality = rs.getString("quality");
				String performance = rs.getString("performance");
				int result = rs.getInt("result");

				listResults.add(new ProductionData(id, date, timecode, lot, offset, pressure, layout, component,
						colorbound, quality, performance, result));
			}
			st.close();
			return listResults;

		} catch (Exception e) {
			System.err.println("Got an exception! ");
			System.err.println(e.getMessage());
		}
		return null;
	}

	/**
	 * Return list of all the productions data from the database filtered by a month
	 * and a year
	 * 
	 * @param month (int)
	 * @param year (int)
	 * @return List<ProductionData>
	 */
	public static List<ProductionData> getReportData(String month, String year) {
		try {
			List<ProductionData> listResults = new ArrayList<ProductionData>();
			String myDriver = "com.mysql.cj.jdbc.Driver";
			String myUrl = "jdbc:mysql://localhost/javaproject?zeroDateTimeBehavior=CONVERT_TO_NULL&serverTimezone=UTC";
			Class.forName(myDriver);
			Connection conn = DriverManager.getConnection(myUrl, "root", "");
			String query = "SELECT * FROM donneesProduction WHERE date like '" + year + "-" + month + "%'";
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery(query);

			while (rs.next()) {
				int id = rs.getInt("id");
				Date date = rs.getDate("date");
				int timecode = rs.getInt("timecode");
				int lot = rs.getInt("lot");
				int offset = rs.getInt("offset");
				int pressure = rs.getInt("pressure");
				int layout = rs.getInt("layout");
				String component = rs.getString("component");
				String colorbound = rs.getString("colorbound");
				String quality = rs.getString("quality");
				String performance = rs.getString("performance");
				int result = rs.getInt("result");

				listResults.add(new ProductionData(id, date, timecode, lot, offset, pressure, layout, component,
						colorbound, quality, performance, result));
			}
			st.close();
			return listResults;

		} catch (Exception e) {
			System.err.println("Got an exception! ");
			System.err.println(e.getMessage());
		}
		return null;
	}

	/**
	 * Return number of elements in database where firstField=firstFieldValue AND
	 * secondField=secondFieldValue
	 * 
	 * @param firstField (String)
	 * @param firstFieldValue (String)
	 * @param secondField (String)
	 * @param secondFieldValue (String)
	 * @return int
	 */
	public static int getCountOfElementFilteredByTwoField(String firstField, String firstFieldValue, String secondField,
			String secondFieldValue) {
		try {
			String myDriver = "com.mysql.cj.jdbc.Driver";
			String myUrl = "jdbc:mysql://localhost/javaproject?zeroDateTimeBehavior=CONVERT_TO_NULL&serverTimezone=UTC";
			Class.forName(myDriver);
			Connection conn = DriverManager.getConnection(myUrl, "root", "");
			String query = "SELECT count(*) FROM donneesProduction WHERE " + firstField + " like '" + firstFieldValue
					+ "' AND " + secondField + " like '" + secondFieldValue + "'";
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery(query);

			while (rs.next()) {
				return (rs.getInt("count(*)"));
			}
		} catch (Exception e) {
			System.err.println("Got an exception! ");
			System.err.println(e.getMessage());
		}
		return (-1);
	}

	/**
	 * Return list of all the productions data from the database where quality OR
	 * performance are low
	 * 
	 * @return List<ProductionData>
	 */
	public static List<ProductionData> getIncorrectData() {
		try {
			List<ProductionData> listResults = new ArrayList<ProductionData>();
			String myDriver = "com.mysql.cj.jdbc.Driver";
			String myUrl = "jdbc:mysql://localhost/javaproject?zeroDateTimeBehavior=CONVERT_TO_NULL&serverTimezone=UTC";
			Class.forName(myDriver);
			Connection conn = DriverManager.getConnection(myUrl, "root", "");
			String query = "SELECT * FROM donneesProduction WHERE quality='Low' OR performance = 'Low'";
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery(query);

			while (rs.next()) {
				int id = rs.getInt("id");
				Date date = rs.getDate("date");
				int timecode = rs.getInt("timecode");
				int lot = rs.getInt("lot");
				int offset = rs.getInt("offset");
				int pressure = rs.getInt("pressure");
				int layout = rs.getInt("layout");
				String component = rs.getString("component");
				String colorbound = rs.getString("colorbound");
				String quality = rs.getString("quality");
				String performance = rs.getString("performance");
				int result = rs.getInt("result");

				listResults.add(new ProductionData(id, date, timecode, lot, offset, pressure, layout, component,
						colorbound, quality, performance, result));
			}
			st.close();
			return listResults;

		} catch (Exception e) {
			System.err.println("Got an exception! ");
			System.err.println(e.getMessage());
		}
		return null;
	}

	/**
	 * Return number of elements in database where field=value
	 * 
	 * @param field (String)
	 * @param value (String)
	 * @return List<ProductionData>
	 */
	public static List<ProductionData> getDataFilteredByAField(String field, String value) {
		try {
			List<ProductionData> listResults = new ArrayList<ProductionData>();
			String myDriver = "com.mysql.cj.jdbc.Driver";
			String myUrl = "jdbc:mysql://localhost/javaproject?zeroDateTimeBehavior=CONVERT_TO_NULL&serverTimezone=UTC";
			Class.forName(myDriver);
			Connection conn = DriverManager.getConnection(myUrl, "root", "");
			String query = "SELECT * FROM donneesProduction WHERE " + field + " like '%" + value + "%'";
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery(query);

			while (rs.next()) {
				int id = rs.getInt("id");
				Date date = rs.getDate("date");
				int timecode = rs.getInt("timecode");
				int lot = rs.getInt("lot");
				int offset = rs.getInt("offset");
				int pressure = rs.getInt("pressure");
				int layout = rs.getInt("layout");
				String component = rs.getString("component");
				String colorbound = rs.getString("colorbound");
				String quality = rs.getString("quality");
				String performance = rs.getString("performance");
				int result = rs.getInt("result");

				listResults.add(new ProductionData(id, date, timecode, lot, offset, pressure, layout, component,
						colorbound, quality, performance, result));
			}
			st.close();
			return listResults;

		} catch (Exception e) {
			System.err.println("Got an exception! ");
			System.err.println(e.getMessage());
		}
		return null;
	}
}