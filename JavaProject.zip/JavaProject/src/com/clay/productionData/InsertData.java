package com.clay.productionData;

import java.sql.*;

import java.io.File;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

/**
 * @author Alexis
 *
 */
public class InsertData {

	/**
	 * Insert data from an XML file of a given filePath into the database
	 * 
	 * @param filePath (String)
	 */
	public static void insertionFichierXML(String filePath) {
		try {
			String myDriver = "com.mysql.cj.jdbc.Driver";
			String myUrl = "jdbc:mysql://localhost/javaproject?zeroDateTimeBehavior=CONVERT_TO_NULL&serverTimezone=UTC";
			Class.forName(myDriver);
			Connection conn = DriverManager.getConnection(myUrl, "root", "");
			String query = "INSERT INTO donneesProduction (date, timecode, lot, offset, pressure, layout, component, colorbound, quality, performance, result) VALUES ('";
			Statement st = conn.createStatement();
			final DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			final DocumentBuilder builder = factory.newDocumentBuilder();

			final Document document = builder.parse(new File(filePath));

			final Element datas = document.getDocumentElement();
			String date = datas.getAttribute("date").toString();
			final NodeList data = datas.getChildNodes();

			final int nbData = data.getLength();

			for (int i = 0; i < nbData; i++) {
				if (data.item(i).getNodeType() == Node.ELEMENT_NODE) {
					final Element dataCourante = (Element) data.item(i);

					String timecode = dataCourante.getAttribute("timecode").toString();
					String lot = dataCourante.getAttribute("lot").toString();
					final Element offsetElement = (Element) dataCourante.getElementsByTagName("offset").item(0);
					String offset = offsetElement.getTextContent();
					final Element pressureElement = (Element) dataCourante.getElementsByTagName("pressure").item(0);
					String pressure = pressureElement.getTextContent();
					final Element layoutElement = (Element) dataCourante.getElementsByTagName("layout").item(0);
					String layout = layoutElement.getTextContent();
					final Element componentElement = (Element) dataCourante.getElementsByTagName("component").item(0);
					String component = componentElement.getTextContent();
					final Element colorboundElement = (Element) dataCourante.getElementsByTagName("colorbound").item(0);
					String colorbound = colorboundElement.getTextContent();
					final Element qualityElement = (Element) dataCourante.getElementsByTagName("quality").item(0);
					String quality = qualityElement.getTextContent();
					final Element performanceElement = (Element) dataCourante.getElementsByTagName("performance")
							.item(0);
					String performance = performanceElement.getTextContent();
					final Element resultElement = (Element) dataCourante.getElementsByTagName("result").item(0);
					String result = resultElement.getTextContent();

					query += date + "', '" + timecode + "', '" + lot + "', '" + offset + "', '" + pressure + "', '"
							+ layout + "', '" + component + "', '" + colorbound + "', '" + quality + "', '"
							+ performance + "', '" + result + "')";
					st.executeUpdate(query);

					// reset the query for next insert
					query = "INSERT INTO donneesProduction (date, timecode, lot, offset, pressure, layout, component, colorbound, quality, performance, result) VALUES ('";
				}
			}
			st.close();
		} catch (Exception e) {
			System.err.println("Got an exception! ");
			System.err.println(e.getMessage());
		}
	}
}
